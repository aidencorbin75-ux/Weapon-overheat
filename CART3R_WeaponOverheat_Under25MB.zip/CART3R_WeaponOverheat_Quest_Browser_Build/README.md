# CART3R Weapon Overheat — BONELAB Quest Patch 6

Requested behavior: firing heats the gun; barrel transitions orange then red; the weapon jams and refuses to fire; at critical heat it explodes.

## Important status
This is a **runtime firearm-API discovery build**, not the finished gameplay mod. The supplied Patch 6 files do not identify verified live firing methods, barrel renderers, or safe explosion/jam hooks. Guessing these can crash BONELAB or break every weapon. This build scans the actual running game and logs candidate firearm types and firing-related method signatures under `[WOH]`.

## Quest-only browser build
1. Create a GitHub repository in the Quest browser.
2. Upload the contents of this folder, including `.github/workflows/build.yml`.
3. Commit to the `main` branch.
4. Open **Actions** → **Build WeaponOverheat** → **Run workflow**.
5. When it finishes, open the run and download `WeaponOverheat-discovery-build`.
6. Extract `WeaponOverheat.dll` and put it in `Android/data/com.StressLevelZero.BONELAB/files/Mods/`.
7. Launch BONELAB, enter a level, wait 10 seconds, then retrieve `Latest.log` and send the `[WOH]` lines.

If GitHub's mobile/Quest upload page cannot upload the hidden `.github` folder, the workflow will not run; tell me what screen you get and I can give an alternate browser-only route.

## Compatibility
Targeted at the supplied runtime: BONELAB 1.2974.57485, Unity 2021.3.16f1, MelonLoader 0.6.5 Open-Beta, .NET 8, Il2CppInterop 1.4.6. The earlier baseline log reports a `RegisterTypeOptions.set_LogSuccess` MissingMethodException during Il2CppInterop initialization. If that still occurs, it must be resolved before reliable runtime hooks can be tested.
