Open CART3R_AdvancedAmmoInteraction_Source/README.md for build/install instructions. This is a discovery build, not yet the finished overheating gameplay mod.
